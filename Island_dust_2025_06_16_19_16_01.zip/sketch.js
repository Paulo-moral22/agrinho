let perguntas = [
  {
    pergunta: "Qual é uma atividade comum no campo?",
    opcoes: ["Surf", "Agricultura", "TI", "Publicidade"],
    resposta: 1
  },
  {
    pergunta: "Qual animal é típico da vida no campo?",
    opcoes: ["Tubarão", "Cavalo", "Leão-marinho", "Golfinho"],
    resposta: 1
  },
  {
    pergunta: "O que se planta frequentemente no campo?",
    opcoes: ["Carros", "Milho", "Celulares", "Roupas"],
    resposta: 1
  },
  {
    pergunta: "Qual destes é um equipamento rural?",
    opcoes: ["Trator", "Drone", "Mouse", "Patins"],
    resposta: 0
  },
  {
    pergunta: "O que o campo oferece para a cidade?",
    opcoes: ["Ar poluído", "Alimentos", "Internet", "Shoppings"],
    resposta: 1
  },
  {
    pergunta: "Onde geralmente se encontra uma fazenda?",
    opcoes: ["Na praia", "Na cidade", "No campo", "No shopping"],
    resposta: 2
  },
  {
    pergunta: "Qual produto vem do campo?",
    opcoes: ["Leite", "Smartphone", "Ônibus", "Elevador"],
    resposta: 0
  },
  {
    pergunta: "Quem trabalha no campo?",
    opcoes: ["Agricultor", "Piloto de avião", "Youtuber", "Recepcionista"],
    resposta: 0
  }
];

let indice = 0;
let pontos = 0;
let recorde = 0;
let jogoFinalizado = false;

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
  textSize(20);
  carregarRecorde();
}

function draw() {
  background(130, 200, 130); // Tema campo

  if (!jogoFinalizado) {
    mostrarPergunta();
  } else {
    mostrarFimDeJogo();
  }

  mostrarPlacar();
}

function mostrarPergunta() {
  fill(255);
  text(perguntas[indice].pergunta, width / 2, 100);

  for (let i = 0; i < 4; i++) {
    fill(50, 150, 50);
    rect(200, 180 + i * 80, 400, 60, 10);
    fill(255);
    text(perguntas[indice].opcoes[i], 400, 210 + i * 80);
  }
}

function mousePressed() {
  if (jogoFinalizado) {
    indice = 0;
    pontos = 0;
    jogoFinalizado = false;
    return;
  }

  for (let i = 0; i < 4; i++) {
    let y = 180 + i * 80;
    if (mouseX > 200 && mouseX < 600 && mouseY > y && mouseY < y + 60) {
      if (i === perguntas[indice].resposta) {
        pontos++;
      }
      indice++;
      if (indice >= perguntas.length) {
        jogoFinalizado = true;
        if (pontos > recorde) {
          recorde = pontos;
          salvarRecorde();
        }
      }
    }
  }
}

function mostrarFimDeJogo() {
  fill(255);
  textSize(28);
  text("Fim de jogo!", width / 2, height / 2 - 60);
  text("Você fez " + pontos + " ponto(s).", width / 2, height / 2);
  text("Clique para jogar novamente.", width / 2, height / 2 + 60);
  textSize(20);
}

function mostrarPlacar() {
  fill(0);
  textSize(18);
  text("Pontos: " + pontos, 80, 30);
  text("Recorde: " + recorde, width - 100, 30);
}

function salvarRecorde() {
  localStorage.setItem("recordeCampo", recorde);
}

function carregarRecorde() {
  let r = localStorage.getItem("recordeCampo");
  if (r !== null) {
    recorde = int(r);
  }
}
